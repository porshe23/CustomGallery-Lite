<?php
defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Uri\Uri;

class PlgContentCustomgallery extends CMSPlugin
{
    public function onContentPrepare($context, &$article, &$params, $page = 0)
    {
        if (!preg_match_all('/\{gallery\}(.*?)\{\/gallery\}/i', $article->text, $matches)) {
            return true;
        }

        $showCaptions = (int) $this->params->get('show_captions', 1);

        $baseUrl = rtrim(Uri::root(), '/');
        $pluginAssets = $baseUrl . '/plugins/content/customgallery/assets';

        // Подключаем GLightbox (CDN)
        HTMLHelper::_('stylesheet', 'https://cdn.jsdelivr.net/npm/glightbox/dist/css/glightbox.min.css');
        HTMLHelper::_('script', 'https://cdn.jsdelivr.net/npm/glightbox/dist/js/glightbox.min.js', [], ['defer' => true]);

        // Подключаем локальные CSS и JS
        HTMLHelper::_('stylesheet', $pluginAssets . '/css/customgallery.css');
        HTMLHelper::_('script', $pluginAssets . '/js/customgallery.js', [], ['defer' => true]);

        foreach ($matches[1] as $key => $folder) {
            $folderName = trim($folder);
            $folderPath = JPATH_SITE . '/images/' . $folderName;
            $webPath    = $baseUrl . '/images/' . $folderName;

            if (!is_dir($folderPath)) {
                continue;
            }

            $images = glob($folderPath . '/*.{jpg,jpeg,png,webp,gif,avif,AVIF,JPG,JPEG,PNG,WEBP}', GLOB_BRACE);

            if (empty($images)) {
                continue;
            }

            $html = '<div class="custom-gallery-grid">';

            foreach ($images as $img) {
                $fileName = basename($img);
                $imgUrl   = $webPath . '/' . $fileName;

                $captionAttr = '';
                $captionHtml = '';

                if ($showCaptions) {
                    $rawName = pathinfo($fileName, PATHINFO_FILENAME);
                    // Преобразуем имя файла (zh1 -> Zh1, zh_10 -> Zh 10)
                    $cleanTitle = htmlspecialchars(ucfirst(str_replace(['-', '_'], ' ', $rawName)), ENT_QUOTES, 'UTF-8');
                    
                    // Атрибуты для всплывающего окна GLightbox
                    $captionAttr = ' data-title="' . $cleanTitle . '" data-glightbox="title: ' . $cleanTitle . ';"';
                    
                    // HTML подпись под превьюшкой в сетке
                    $captionHtml = '<div class="gallery-caption">' . $cleanTitle . '</div>';
                }

                $html .= '<div class="gallery-item">';
                $html .= '<a href="' . $imgUrl . '" class="glightbox"' . $captionAttr . '>';
                $html .= '<img src="' . $imgUrl . '" alt="' . $fileName . '" loading="lazy">';
                $html .= '</a>';
                $html .= $captionHtml; // Подпись под карточкой
                $html .= '</div>';
            }

            $html .= '</div>';

            $article->text = str_replace($matches[0][$key], $html, $article->text);
        }

        return true;
    }
}