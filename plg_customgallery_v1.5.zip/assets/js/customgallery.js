document.addEventListener('DOMContentLoaded', function () {
    // Проверяем наличие элемента галереи и загруженность GLightbox
    if (document.querySelector('.glightbox') && typeof GLightbox !== 'undefined') {
        GLightbox({
            selector: '.glightbox',
            touchNavigation: true,
            loop: true
        });
    }
});